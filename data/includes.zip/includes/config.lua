-- Config files

-- Server details
server = "NocSouls"

-- Display info in chat settings
config = {}
config.showSpellInfo = false
config.showFastCastInfo = true
config.showCancelInfo = true

enspell_list = S{"Enstone", "Enwater", "Enaero", "Enfire", "Enblizzard", "Enthunder", "Enlight","Endark"}
